<footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">هنا توضع الحقوق محفوظة وما إلى ذلك، لم أدر ماذا أكتب فعلاـ سأفكر في ذلك لاحقا</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <!-- <script src="vendor/jquery/jquery.min.js"></script> -->
    <script
  src="http://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
