

<div class="card my-4">
    <h5 class="card-header">إعلان</h5>
    <a href="https://youdo.blog/youarecool/" target="_blank"><img src="images/ads/novel.jpg" class="card-img-top" alt="روابة إيفيانا بسكال"></a>
    <div class="card-body">
    <h5 class="card-title"><a href="https://youdo.blog/youarecool/"><b>روابة إيفيانا بسكال من كتابة المبدع يونس بن عمارة</b></a></h5>
    </div>
  </div>

  <div class="card my-4">
    <h5 class="card-header">  إعلان 2</h5>
    <a href="http://bit.ly/2NeQudz" target="_blank"><img src="images/ads/lezr_web.jpeg" class="card-img-top" alt="شعار شركة Lezr"></a>
    <div class="card-body">
    <h5 class="card-title"><a href="http://bit.ly/2NeQudz"><b>lezr Web</b></a>: لتطوير الويب، وبيع النسخ الأصلية من البرامج، ولأمنية المعلومات، واستضافة المواقع  وغيرها...</h5>
    </div>
  </div>

  
<div class="card my-4">
    <h5 class="card-header">حساباتي الاجتماعية</h5>
    <div class="card-body">
      <a href="https://www.facebook.com/watheq.show">  <i class="fab fa-facebook fa-3x"></i></a>  &nbsp;
     
      <a href="https://twitter.com/watheq_show"><i class="fab fa-twitter fa-3x"> </i></a>  &nbsp;
      <a href="https://github.com/watheqAlshowaiter"><i class="fab fa-github fa-3x"> </i></a>  &nbsp;
    </div>
  </div>

  
