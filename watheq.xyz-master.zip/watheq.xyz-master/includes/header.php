<!DOCTYPE html>
<html lang="utf-8" >

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>مدونة واثق</title>
    <link rel="shortcut icon" href="images/icon/icon.png">
<!-- <link rel="icon" href="/favicon.ico" type="image/x-icon"> -->

    <!-- Bootstrap core CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">

    <link href="vendor/bootstrap/css/bootstrap_rtl.css" rel="stylesheet">

    <!-- font awosome -->
    <!-- <link href="admin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">



    <!-- Custom styles for this template -->
    <link href="css/blog-post.css?v=0.001" rel="stylesheet">

  <body>