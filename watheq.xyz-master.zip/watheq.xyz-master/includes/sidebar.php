        <div class="col-md-4">

          <!-- Search Widget -->
          <div class="card my-4">
            <h5 class="card-header">ابحث </h5>
            <div class="card-body">
              <form action="search.php" method="post">
              <div class="input-group">
                <input name = "search" type="text" class="form-control" placeholder="ابحث عن ... ">
                <span class="input-group-btn">
                  <button name="submit" class="btn btn-secondary" type="submit">هيا!</button>
                </span>
              </div>
              </form>
            </div>
          </div>

          <!-- Categories Widget -->
          <?php 
              $query = "SELECT * FROM categories limit 8"; 
              $select_catgs_sidebar = mysqli_query($connection, $query);

             ?>
          <div class="card my-4  text-white bg-secondary mb-3">
            <h5 class="card-header">تصنيفات</h5>
            <div class="card-body">
              <div class="row">
                <div class="col-lg-6">
                  <ul class="list-unstyled mb-0">
                    <?php 

                      while ($row = mysqli_fetch_assoc($select_catgs_sidebar)) {
                        $cat_id = $row['cat_id']; 
                        $cat_title = $row['cat_title']; 
                        echo "<li><a href='category.php?cat_id={$cat_id}' class='text-white'> {$cat_title}</a></li>";
                      }
                     ?>
                    
                  </ul>
                </div>
                <!-- <div class="col-lg-6">
                  <ul class="list-unstyled mb-0">
                    <li>
                      <a href="#">JavaScript</a>
                    </li>
                    <li>
                      <a href="#">CSS</a>
                    </li>
                    <li>
                      <a href="#">Tutorials</a>
                    </li>
                  </ul>
                </div> -->
              </div>
            </div>
          </div>

          <!-- Side Widget -->
          <?php include 'includes/widget.php'; ?>

        </div>