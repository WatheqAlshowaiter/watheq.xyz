<?php include 'includes/db.php' ?>
<?php include 'includes/header.php'; ?>

    <!-- Navigation -->

<?php include 'includes/navigation.php'; ?>

<?php 

if (isset($_GET['p_id'])) {
    $post_id = $_GET['p_id']; 
    $query = "SELECT * FROM posts WHERE post_id = $post_id limit 1"; 
    $select_post_by_id = mysqli_query($connection, $query);

   while ($row = mysqli_fetch_assoc($select_post_by_id)) {
     $post_id = $row['post_id']; 
     $cat_id = $row['cat_id'];
     $post_title = $row['post_title']; 
     //$post_author = $row['post_author'];
     $post_date = $row['post_date'];
     $post_image = $row['post_image'];
     $post_content = $row['post_content'];
     $post_tags = $row['post_tags'];
     $post_comment_count = $row['post_comment_count'];
     $post_status = $row['post_status'];
    }}

 ?>


    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-12 text-center">

          <?php 
             $query = "SELECT * FROM posts where post_id = $post_id limit 1"; 
              $select_the_post = mysqli_query($connection, $query);

              $row = mysqli_fetch_assoc($select_the_post); 


              // there is no need for while or ant loop becaues it is just a one post 
              // while ($row = mysqli_fetch_assoc($select_the_post)) {
               
               ?> 



          <!-- Title -->
          <h1 class="mt-4"><?php echo $row['post_title']; ?></h1>

          <!-- Author -->
          <!-- there is no author because all post by me -->

          <hr>

          <!-- Date/Time -->
          <p> <?php echo $row['post_date']; ?></p>

          <hr>
          <!-- Preview Image -->
          <!-- <img src="images/<?php// echo $row['post_image'] ;?>" class ="img-fluid rounded"> -->
          <!-- <img class="img-fluid rounded" src="http://placehold.it/900x300" alt=""> -->

          <!-- <hr> -->

          <!-- Post Content -->
          <div class="post_content_long">
            <?php echo $row['post_content']; ?>
              </div>
          
         

          <hr>

          <p><?php echo "وسوم: " . $row['post_tags']; ?></p>


          <!-- <?php //}  // end of posts ?> -->

        </div>

                            

        <!-- Sidebar Widgets Column -->
        <!-- if I want it in my single posts uncomment this line -->
        <?php //include 'includes/sidebar.php' ?>

      </div>
      <!-- /.row -->
      <!--Comment Section --> 
      <div class="commentbox" id="post<?php echo $post_id; ?>"></div>
      <script src="https://unpkg.com/commentbox.io/dist/commentBox.min.js"></script>

      <script> 
      // commentBox('5715241090416640-proj');
      // import qs from 'qs';
commentBox('5715241090416640-proj', {
    className: 'commentbox', // the class of divs to look for
    defaultBoxId: 'commentbox', // the default ID to associate to the div
    tlcParam: 'tlc', // used for identifying links to comments on your page
    backgroundColor: null, // default transparent
    textColor: null, // default black
    subtextColor: null, // default grey
    singleSignOn: null, // enables Single Sign-On (for Professional plans only)
    /**
     * Creates a unique URL to each box on your page.
     * 
     * @param {string} boxId
     * @param {Location} pageLocation - a copy of the current window.location
     * @returns {string}
     */
    createBoxUrl(boxId, pageLocation) {

        pageLocation.search = ''; // removes query string!
        pageLocation.hash = boxId; // creates link to this specific Comment Box on your page
        return pageLocation.href; // return url string
    },
    /**
     * Fires once the plugin loads its comments.
     * May fire multiple times in its lifetime.
     * 
     * @param {number} count
     */
    onCommentCount(count) {

    }


});


      </script> 

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>